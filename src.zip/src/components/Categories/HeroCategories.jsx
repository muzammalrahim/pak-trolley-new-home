import React from 'react'
import cover from './icons/cover.png'
export const HeroCategories = () => {
  return (
    
      <img className='h-full' src={cover} alt="" height={""} width={""}  />
  )
}
